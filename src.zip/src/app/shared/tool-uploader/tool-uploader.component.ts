import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'epsi-tool-uploader',
  templateUrl: './tool-uploader.component.html',
  styleUrls: ['./tool-uploader.component.scss']
})
export class ToolUploaderComponent implements OnInit {

  public url: string

  constructor() { }

  ngOnInit() {
  }

}
