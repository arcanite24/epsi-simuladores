import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'epsi-content-error-modal',
  templateUrl: './content-error-modal.component.html',
  styleUrls: ['./content-error-modal.component.scss']
})
export class ContentErrorModalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
