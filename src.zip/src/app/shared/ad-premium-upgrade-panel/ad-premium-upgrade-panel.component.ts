import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'epsi-ad-premium-upgrade-panel',
  templateUrl: './ad-premium-upgrade-panel.component.html',
  styleUrls: ['./ad-premium-upgrade-panel.component.scss']
})
export class AdPremiumUpgradePanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
