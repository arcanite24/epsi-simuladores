import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'epsi-terminos-modal',
  templateUrl: './terminos-modal.component.html',
  styleUrls: ['./terminos-modal.component.scss']
})
export class TerminosModalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
