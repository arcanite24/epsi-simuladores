import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'epsi-stat-view-add',
  templateUrl: './stat-view-add.component.html',
  styleUrls: ['./stat-view-add.component.scss']
})
export class StatViewAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
