import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'epsi-ad-pit-panel',
  templateUrl: './ad-pit-panel.component.html',
  styleUrls: ['./ad-pit-panel.component.scss']
})
export class AdPitPanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
